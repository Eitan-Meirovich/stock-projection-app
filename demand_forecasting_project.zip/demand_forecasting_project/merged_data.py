import pandas as pd

# Rutas de los archivos
projections_path = r'C:\Users\Ukryl\stock-projection-app\demand_forecasting_project\data\output\Consolidated_forecast.csv'
sales_paths = {
    "bebé": r'C:\Users\Ukryl\stock-projection-app\demand_forecasting_project\data\input\Bebé.xlsx',
    "hilos_verano": r'C:\Users\Ukryl\stock-projection-app\demand_forecasting_project\data\input\Hilos Verano.xlsx',
    "invierno": r'C:\Users\Ukryl\stock-projection-app\demand_forecasting_project\data\input\Invierno.xlsx'
}

# Procesar datos de ventas
def process_sales_data(path, super_family_name):
    df = pd.read_excel(path)
    df = df.rename(columns={
        "Fecha": "Date",
        "Super Familia": "SuperFamily",
        "Codigo Producto": "Codigo Producto",
        "Familia": "Familia",
        "Venta": "Sales"
    })
    df["SuperFamily"] = super_family_name
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")  # Convertir a datetime64[ns]
    # Registrar filas con fechas no válidas
    invalid_dates = df[df["Date"].isna()]
    if not invalid_dates.empty:
        invalid_dates.to_csv(f"invalid_dates_{super_family_name}.csv", index=False)
        print(f"Registros con fechas no válidas exportados para {super_family_name}")
    return df[~df["Date"].isna()][["Date", "Familia", "SuperFamily", "Codigo Producto", "Sales"]]

# Cargar y procesar datos de ventas
bebe_sales = process_sales_data(sales_paths["bebé"], "Bebé")
verano_sales = process_sales_data(sales_paths["hilos_verano"], "Hilos Verano")
invierno_sales = process_sales_data(sales_paths["invierno"], "Invierno")

# Consolidar datos de ventas
sales_data = pd.concat([bebe_sales, verano_sales, invierno_sales], ignore_index=True)

# Cargar y procesar datos de proyecciones
forecast_df = pd.read_csv(projections_path)
forecast_df = forecast_df.rename(columns={"Super Familia": "SuperFamily"})
forecast_df["Date"] = pd.to_datetime(forecast_df["Date"], errors="coerce")  # Convertir a datetime64[ns]
# Registrar filas con fechas no válidas en proyecciones
invalid_forecast_dates = forecast_df[forecast_df["Date"].isna()]
if not invalid_forecast_dates.empty:
    invalid_forecast_dates.to_csv("invalid_forecast_dates.csv", index=False)
    print("Registros con fechas no válidas exportados para proyecciones")
forecast_df = forecast_df[~forecast_df["Date"].isna()]

# Asegurar que las columnas sean consistentes antes de combinar
forecast_df["Sales"] = None  # Las proyecciones no tienen ventas reales
forecast_df = forecast_df[["Date", "Familia", "SuperFamily", "Codigo Producto", "Projection", "Sales"]]
sales_data["Projection"] = None  # Las ventas no tienen proyecciones
sales_data = sales_data[["Date", "Familia", "SuperFamily", "Codigo Producto", "Projection", "Sales"]]

# Intentar combinar los datos usando 'Codigo Producto' como columna clave principal
merged_data = pd.merge(
    forecast_df,
    sales_data,
    on=["Codigo Producto"],
    how="outer",
    suffixes=("_forecast", "_sales"),
    indicator=True  # Agregar indicador para verificar coincidencias
)

# Registrar filas que no coinciden
non_matching_forecast = merged_data[merged_data["_merge"] == "left_only"]
non_matching_sales = merged_data[merged_data["_merge"] == "right_only"]

if not non_matching_forecast.empty:
    non_matching_forecast.to_csv("non_matching_forecast.csv", index=False)
    print("Registros de proyecciones sin ventas exportados")

if not non_matching_sales.empty:
    non_matching_sales.to_csv("non_matching_sales.csv", index=False)
    print("Registros de ventas sin proyecciones exportados")

# Asegurarse de que las fechas estén correctamente formateadas y truncadas a YYYY-MM-DD
merged_data["Date_forecast"] = pd.to_datetime(merged_data["Date_forecast"], errors="coerce")
merged_data["Date_sales"] = pd.to_datetime(merged_data["Date_sales"], errors="coerce")

merged_data["Date_forecast"] = merged_data["Date_forecast"].dt.strftime('%Y-%m-%d')
merged_data["Date_sales"] = merged_data["Date_sales"].dt.strftime('%Y-%m-%d')
if "Sales" in merged_data.columns:
    merged_data["Sales"] = merged_data["Sales"].apply(
        lambda x: f"{int(x):,}".replace(",", "X").replace(".", ",").replace("X", ".") if pd.notnull(x) else x)


output_path = r'C:\Users\Ukryl\stock-projection-app\demand_forecasting_project\data\output\merged_data.csv'
merged_data.to_csv(output_path, index=False)


print(f"Archivo consolidado generado exitosamente: {output_path}")